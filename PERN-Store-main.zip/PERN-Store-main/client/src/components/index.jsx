export { AccountForm as default } from "./AccountForm";
